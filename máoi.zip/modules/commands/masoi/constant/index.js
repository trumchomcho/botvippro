module.exports = {
	Data: require('./Data'),
	FunnyDeaths: require('./FunnyDeaths')
};
